PKG Studio 0.7.4 - portable Windows x64 demo build

Run PKGStudio.exe. Demo samples are in the samples folder (File > Open, or the
Welcome page). No installer is needed for this folder: copy it anywhere.

This build is unsigned, so Windows SmartScreen may warn on first launch. It is a
development demo, not a signed release: Help > Feature status lists what is
implemented, partial and planned.

Installed with the setup program instead? Use Start menu > PKG Studio, and
Settings > Apps > PKG Studio to uninstall.
